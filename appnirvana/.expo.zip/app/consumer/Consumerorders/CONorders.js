import React, { useEffect, useState ,useRef } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity ,Animated} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

  
  const CustomToggle = ({ onToggle }) => {
   const [selected, setSelected] = useState(2);
   const moveAnim = useRef(new Animated.Value(2)).current;
  
   const handleToggle = (value) => {
     Animated.spring(moveAnim, {
       toValue: value,
       useNativeDriver: true,
       speed: 12,
       bounciness: 5,
     }).start();
     setSelected(value);
     if (onToggle) {
       onToggle(value);
     }
   };
  
   const translateX = moveAnim.interpolate({
     inputRange: [1, 2],
     outputRange: [0, 108], // Adjusted for 2 options
   });
  
   return (
     <View style={styles.toggleContainer}>
       <View style={styles.toggleWrapper}>
         <Animated.View 
           style={[
             styles.highlightBg, 
             { transform: [{ translateX }] }
           ]} 
         />
         <TouchableOpacity 
           style={styles.toggleOption}
           onPress={() => handleToggle(1)}
         >
           <Text style={[
             styles.toggleText, 
             selected === 1 && styles.selectedText
           ]}>
             Home
           </Text>
         </TouchableOpacity>
         <TouchableOpacity 
           style={styles.toggleOption}
           onPress={() => handleToggle(2)}
         >
           <Text style={[
             styles.toggleText, 
             selected === 2 && styles.selectedText
           ]}>
             My Orders
           </Text>
         </TouchableOpacity>
       </View>
     </View>
   );
  };

export default function CONorders({ route ,navigation }) {
  const { uniqueid } = route.params;
  

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleToggleChange = (value) => {
    if(value === 1) {
      // Handle Home
      navigation.navigate('HomeCon', { uniqueid });
    } else {
      // Handle My Orders
      navigation.navigate('CONorders', { uniqueid });
    }
  };

  const fetchOrders = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:5000/get_orders/${uniqueid}`);
      const result = await response.json();

      if (result.status === "success") {
        setOrders(result.data);
      } else {
        setError(result.message);
      }
    } catch (error) {
      setError("Failed to fetch orders. Please try again.");
    } finally {
      setLoading(false);
    }
  };


  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0a47f0" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }
 
  const renderOrderItem = ({ item }) => (

    <TouchableOpacity style={styles.orderItem}>
      <View style={styles.orderHeader}>
        <Text style={styles.orderId}>Order ID: {item.order_id}</Text>
        {item.status === 'paid' ? (
          <View style={styles.paidStatus}>
            <Ionicons name="checkmark-circle" size={18} color="#4CAF50" />
            <Text style={[styles.orderStatus, { color: '#4CAF50' }]}>Paid</Text>
          </View>
        ) : (
          <View style={styles.unpaidStatus}>
            <Ionicons name="close-circle" size={18} color="#F44336" />
            <Text style={[styles.orderStatus, { color: '#F44336' }]}>Unpaid</Text>
          </View>
        )}
      </View>
      <View style={styles.orderDetails}>
        <Text style={styles.orderText}>
          <Ionicons name="person" size={18} color="#0a47f0" /> {item.customer_name}
        </Text>
        <Text style={styles.orderText}>
          <Ionicons name="time" size={18} color="#0a47f0" /> {item.date_time}
        </Text>
        <Text style={styles.orderText}>
          <Ionicons name="card" size={18} color="#0a47f0" /> Total: {item.total}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Consumer Orders </Text>
      {orders.length === 0 ? (
        <Text style={styles.noOrdersText}>No orders found.</Text>
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderOrderItem}
          contentContainerStyle={styles.listContainer}
        />
      )}
             <CustomToggle onToggle={handleToggleChange} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f0f0',
    paddingTop: 40,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    color: '#0a47f0',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  noOrdersText: {
    fontSize: 18,
    color: '#888',
    textAlign: 'center',
    marginTop: 40,
  },
  listContainer: {
    paddingBottom: 20,
  },
  orderItem: {
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  orderId: {
    fontSize: 18,
    color: '#333',
    fontWeight: 'bold',
  },
  paidStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  unpaidStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  orderStatus: {
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  orderDetails: {
    paddingVertical: 15,
    paddingHorizontal: 20,
  },
  orderText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    textAlign: 'center',
    marginTop: 40,
  },
  toggleContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
  },
  toggleWrapper: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 25,
    position: 'relative',
    width: 220,
    height: 44,
    padding: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  highlightBg: {
    position: 'absolute',
    width: '48%', // Adjusted for 2 options
    height: '100%',
    backgroundColor: '#000000',
    borderRadius: 22,
    top: 0,
    left: 2,
    bottom: 0,
    margin: 2,
    zIndex: 1,
  },
  toggleOption: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
    height: 40,
  },
  toggleText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#666',
  },
  selectedText: {
    color: '#ffffff',
    fontWeight: '600',
  }
});